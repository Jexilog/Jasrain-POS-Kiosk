import React, { useState } from 'react';
import { toast } from 'react-toastify';
import Icon from '../../../components/Icon';
import QrCode from '../../../components/QrCode';
import { useKiosk } from '../../../context/KioskContext';
import { MESSENGER_PAGE, MESSENGER_LINK, SHOP_EMAIL, ONLINE_FILE_HOURS } from '../../../config/sendFile';
import { findFiles, downloadOnlineFile } from '../../../utils/incoming';

const formatSize = (bytes = 0) =>
  bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;

const timeOf = (iso) => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

// Screen 2b: Messenger or email. Staff attach what the customer sent, the customer finds it by name or email.
export default function OnlineStep({ start, onFile, onBack }) {
  const { t } = useKiosk();
  const [source, setSource] = useState(start === 'email' ? 'email' : 'messenger');
  const [who, setWho] = useState('');
  const [found, setFound] = useState(null); // null = not searched yet
  const [picked, setPicked] = useState(null);
  const [busy, setBusy] = useState(false);

  const isMessenger = source === 'messenger';

  const switchTo = (s) => {
    setSource(s);
    setWho('');
    setFound(null);
    setPicked(null);
  };

  const search = async (e) => {
    if (e) e.preventDefault();
    if (who.trim().length < 3) {
      toast.error(isMessenger ? t('Type your Messenger name.') : t('Type your email address.'));
      return;
    }
    setBusy(true);
    try {
      const list = await findFiles(source, who);
      setFound(list);
      setPicked(list[0] || null);
    } catch (err) {
      setFound(null);
      toast.error(err.message);
    } finally {
      setBusy(false);
    }
  };

  const useIt = async () => {
    if (!picked) return;
    setBusy(true);
    try {
      const file = await downloadOnlineFile(picked.ref, picked.fileName, picked.fileType);
      onFile(file, { source: isMessenger ? 'Messenger' : 'Email', ref: picked.ref });
    } catch (err) {
      toast.error(err.message);
      setBusy(false);
    }
  };

  return (
    <>
      <div className="prStepHead prStepHeadRow">
        <h1 className="prStepTitle"><span className="prNum">1</span> {t('Find your file')}</h1>
        <div className="prTabs" role="tablist" aria-label="Where did you send it">
          <button role="tab" aria-selected={isMessenger} className={isMessenger ? 'active' : ''} onClick={() => switchTo('messenger')}>Messenger</button>
          <button role="tab" aria-selected={!isMessenger} className={!isMessenger ? 'active' : ''} onClick={() => switchTo('email')}>Email</button>
        </div>
      </div>

      <div className="prOnlineGrid">
        <div className="prHowCard">
          <div className="prKicker">{t('NOT SENT YET?')}</div>
          {isMessenger ? (
            <>
              <div className="prStepRow compact"><span className="prStepBadge small">1</span><div>{t('Open Messenger and message')}<br /><b>{MESSENGER_PAGE}</b></div></div>
              <div className="prStepRow compact"><span className="prStepBadge small">2</span><div>{t('Send your file as an attachment. Say how many copies you need.')}</div></div>
              <div className="prStepRow compact"><span className="prStepBadge small">3</span><div>{t('Come back here and type your Messenger name.')}</div></div>
              <div className="prQrRow">
                <QrCode value={MESSENGER_LINK} size={72} label="Open our Messenger page" />
                <div>{t('Scan to open our Messenger page, or find us at')}<br /><b>{MESSENGER_LINK.replace(/^https?:\/\//, '')}</b></div>
              </div>
            </>
          ) : (
            <>
              <div className="prStepRow compact"><span className="prStepBadge small">1</span><div>{t('Open your email and write to')}<br /><b>{SHOP_EMAIL}</b></div></div>
              <div className="prStepRow compact"><span className="prStepBadge small">2</span><div>{t('Attach your file. Say how many copies you need.')}</div></div>
              <div className="prStepRow compact"><span className="prStepBadge small">3</span><div>{t('Come back here and type the email address you sent it from.')}</div></div>
            </>
          )}
          <p className="prMuted prSmall">{t('Our staff add your file here after they get it, so it may take a minute.')}</p>
        </div>

        <div className="prFindCol">
          <form className="prFindForm" onSubmit={search}>
            <label htmlFor="prWho" className="prFindLabel">{isMessenger ? t('Your Messenger name') : t('Your email address')}</label>
            <div className="prFindRow">
              <input
                id="prWho"
                value={who}
                onChange={(e) => setWho(e.target.value)}
                placeholder={isMessenger ? 'Juan Dela Cruz' : 'juan@gmail.com'}
                type={isMessenger ? 'text' : 'email'}
                autoComplete="off"
                autoCapitalize="off"
                spellCheck="false"
              />
              <button className="prPrimary" type="submit" disabled={busy}>
                <Icon name="search" size={22} /> {t('Find my file')}
              </button>
            </div>
            <div className="prMuted prSmall">
              {isMessenger ? `${t('Type it exactly as it shows on Messenger.')} ` : ''}{t('Files from the last {h} hours only.', { h: ONLINE_FILE_HOURS })}
            </div>
          </form>

          {found && (
            <>
              <div className="prKicker">
                {found.length === 0 ? t('NO FILES FOUND') : t(found.length > 1 ? '{n} FILES FOUND' : '{n} FILE FOUND', { n: found.length })}
              </div>
              {found.length === 0 && (
                <p className="prMuted prNone">
                  {isMessenger ? t('We could not find a file for that name. Check the spelling, or ask staff.') : t('We could not find a file for that email. Check the spelling, or ask staff.')}
                </p>
              )}
              {found.map((f) => {
                const on = picked && picked.ref === f.ref;
                return (
                  <button key={f.ref} className={`prFound${on ? ' active' : ''}`} onClick={() => setPicked(f)} aria-pressed={on}>
                    <span className="prFoundIcon"><Icon name="file" size={26} /></span>
                    <span className="prFoundInfo">
                      <strong>{f.fileName}</strong>
                      <span>{formatSize(f.fileSize)} · {t('received {time}', { time: timeOf(f.createdAt) })}</span>
                    </span>
                    <span className={`prFoundCheck${on ? ' on' : ''}`}>{on && <Icon name="check" size={20} />}</span>
                  </button>
                );
              })}
            </>
          )}
        </div>
      </div>

      <div className="prStepFoot">
        <button className="auxButton" onClick={onBack}><Icon name="arrow-left" size={20} /> {t('Choose another way')}</button>
        <button className="prPrimary" onClick={useIt} disabled={!picked || busy}>
          {busy && picked ? t('Getting your file…') : t('Use this file')} <Icon name="arrow-right" size={22} />
        </button>
      </div>
    </>
  );
}
